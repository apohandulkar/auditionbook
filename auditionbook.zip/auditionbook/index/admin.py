from django.contrib import admin
from .models import Admin, Subscription, Feed, UserProfile,Post
admin.site.register(Subscription)
admin.site.register(Admin)
admin.site.register(Feed)
admin.site.register(Post)
admin.site.register(UserProfile)
