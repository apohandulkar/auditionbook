from django import forms
from .models import Feed
from .models import Post
from .models import CommentOnFeed
from .models import CommentOnPost
from .models import CommentOnVideo
from .models import Video


class FeedForm(forms.ModelForm):
    caption = forms.CharField(required=False)
    class Meta:
        model = Feed
        fields = ['image', 'caption']

class PostForm(forms.ModelForm):
    discription = forms.CharField(
        label='',
        widget= forms.Textarea(attrs={
            'row': '1',
            'placeholder': 'Type audition details......'
        }))
    send_portfolio_on = forms.CharField()
    send_portfolio_on_mail = forms.BooleanField(required=False)

    class Meta:
        model = Post
        fields = ['discription', 'send_portfolio_on', 'send_portfolio_on_mail']

class VideoForm(forms.ModelForm):
    class Meta:
        model = Video
        fields = ['video']


class FeedCommentForm(forms.ModelForm):
    comment = forms.CharField()

    class Meta:
        model = CommentOnFeed
        fields = ['comment']


class PostCommentForm(forms.ModelForm):
    comment = forms.CharField()

    class Meta:
        model = CommentOnPost
        fields = ['comment']

class VideoCommentForm(forms.ModelForm):
    comment = forms.CharField()

    class Meta:
        model = CommentOnVideo
        fields = ['comment']
