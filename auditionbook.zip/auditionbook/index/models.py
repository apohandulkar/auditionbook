from django.db import models
from datetime import datetime, timedelta
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models.signals import post_save
from django.dispatch import receiver
from .validators import file_size
# User Subscription model
class Subscription(models.Model):
    subscriber = models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
    name = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.name

# Feed post uploaded by subscribed users
class Feed(models.Model):
    image = models.ImageField(upload_to ='UserPost/')
    caption = models.CharField(max_length=200, null=True, blank=True)
    created_on = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    likes = models.ManyToManyField(User, blank=True, related_name= 'likes')
    dislikes = models.ManyToManyField(User, blank=True, related_name= 'dislikes')

# comment on suscriber created posts
class CommentOnFeed(models.Model):
    comment = models.TextField()
    created_on = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete= models.CASCADE)
    post = models.ForeignKey('Feed', on_delete= models.CASCADE)
    like = models.ManyToManyField(User, blank= True, related_name='feed_comment_like')

# Casting director asigning model
class Admin(models.Model):
    admin = models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
    name = models.CharField(max_length=200, null=True, blank=True)
    date = models.DateTimeField(default=timezone.now)
    def __str__(self):
        return self.name


# Post model for admin posts which can bee seen by subscriber
class Post(models.Model):
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    created_on = models.DateTimeField(default=timezone.now)
    discription =models.TextField()
    send_portfolio_on = models.CharField(max_length=30, null= True, blank= True)
    send_portfolio_on_mail = models.BooleanField()
    likes = models.ManyToManyField(User, blank=True, related_name= 'like')
    dislikes = models.ManyToManyField(User, blank=True, related_name= 'dislike')


# Comment model for post
class CommentOnPost(models.Model):
    comment = models.TextField()
    created_on = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete= models.CASCADE)
    post = models.ForeignKey('Post', on_delete= models.CASCADE)
    like = models.ManyToManyField(User, blank= True, related_name='post_comment_like')
class UserProfile(models.Model):
    user = models.OneToOneField(User, primary_key=True, verbose_name='user', related_name='profile', on_delete=models.CASCADE)
    name = models.CharField(max_length=30, blank=True, null=True)
    age = models.CharField(max_length=2, blank=True, null=True)
    height = models.CharField(max_length=10, blank=True, null=True)
    languages = models.CharField(max_length=100, blank=True, null=True)
    bio = models.TextField(max_length=400, blank=True, null= True)
    experience = models.TextField(max_length=400, blank=True, null=True)
    birth_date = models.DateField(null=True, blank=True)
    location = models.CharField(max_length=100, blank=True, null=True)
    profile_picture = models.ImageField(upload_to='uploads/profile_pictures', default='uploads/profile_pictures/user.png', blank=True)
    followers = models.ManyToManyField(User, blank=True, related_name='followers')
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)
@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()

class Video(models.Model):
    video = models.FileField(upload_to ="UserVideo/%y%m", validators=[file_size])
    created_on = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    likes = models.ManyToManyField(User, blank=True, related_name= 'vlike')
    dislikes = models.ManyToManyField(User, blank=True, related_name= 'vdislike')

class CommentOnVideo(models.Model):
    comment = models.TextField()
    created_on = models.DateTimeField(default=timezone.now)
    author = models.ForeignKey(User, on_delete= models.CASCADE)
    post = models.ForeignKey('Video', on_delete= models.CASCADE)
    like = models.ManyToManyField(User, blank= True, related_name='video_comment_like')