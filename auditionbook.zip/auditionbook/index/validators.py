# from django.core.exceptions import validationError
from django.core.exceptions import ValidationError
def file_size(value):
    filesize = value.size
    if filesize>20971520:
        raise ValidationError("maximum size is 20 mb")