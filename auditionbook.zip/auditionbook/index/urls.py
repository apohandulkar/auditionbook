from django.urls import path
from . import views
from .views import FeedView
from .views import PostView
from .views import VideoView
from .views import FeedDetailView
from .views import PostDetailView
from .views import VideoDetailView
from .views import FeedEditView
from .views import PostEditView
from .views import FeedDeleteView
from .views import PostDeleteView
from .views import VideoDeleteView
from .views import FeedCommentDeleteView
from .views import PostCommentDeleteView
from .views import VideoCommentDeleteView
from .views import ProfileView
from .views import ProfileEditView
from .views import AddFollower
from .views import RemoveFollower
from .views import FeedAddLike
from .views import PostAddLike
from .views import VideoAddLike
from .views import FeedCommentAddLike
from .views import PostCommentAddLike
from .views import VideoCommentAddLike
from .views import UserSearch
urlpatterns = [
    path('', views.index, name='index'),
    path('feed/', FeedView.as_view(), name='feed'),
    path('feed/<int:pk>', FeedDetailView.as_view(), name='feed_detail'),
    path('feed/edit/<int:pk>/', FeedEditView.as_view(), name='feed_edit'),
    path('feed/delete/<int:pk>/', FeedDeleteView.as_view(), name= 'feed_delete'),
    path('feed/<int:post_pk>/comment/delete/<int:pk>/', FeedCommentDeleteView.as_view(), name= 'feedcomment_delete'),
    path('feed/<int:pk>/like', FeedAddLike.as_view(), name= 'feedlike'),
    path('feed/<int:post_pk>/comment/<int:pk>/like', FeedCommentAddLike.as_view(), name= 'feedcommentlike'),

    path('profile/<int:pk>/', ProfileView.as_view(), name= 'profile'),
    path('profile/edit/<int:pk>/', ProfileEditView.as_view(), name= 'profile_edit'),
    path('profile/<int:pk>/followers/add', AddFollower.as_view(), name= 'add_follower'),
    path('profile/<int:pk>/followers/remove', RemoveFollower.as_view(), name= 'remove_follower'),

    path('post/', PostView.as_view(), name='post'),
    path('post/<int:pk>/', PostDetailView.as_view(), name='post_detail'),
    path('post/edit/<int:pk>/', PostEditView.as_view(), name='post_edit'),
    path('post/delete/<int:pk>/', PostDeleteView.as_view(), name='post_delete'),
    path('post/<int:post_pk>/comment/delete/<int:pk>/', PostCommentDeleteView.as_view(), name= 'postcomment_delete'),
    path('post/<int:pk>/like', PostAddLike.as_view(), name= 'postlike'),
    path('post/<int:post_pk>/comment/<int:pk>/like', PostCommentAddLike.as_view(), name= 'postcommentlike'),

    path('video/', VideoView.as_view(), name='video'),
    path('video/<int:pk>/', VideoDetailView.as_view(), name='video_detail'),
    path('video/delete/<int:pk>/', VideoDeleteView.as_view(), name='video_delete'),
    path('video/<int:post_pk>/comment/delete/<int:pk>/', VideoCommentDeleteView.as_view(), name= 'videocomment_delete'),
    path('video/<int:pk>/like', VideoAddLike.as_view(), name= 'videolike'),
    path('video/<int:post_pk>/comment/<int:pk>/like', VideoCommentAddLike.as_view(), name= 'videocommentlike'),

    path('success/', views.success, name='success'),
    path('cancel/', views.cancel, name='cancel'),
    path('failure/', views.failure, name='failure'),

    path('search/', UserSearch.as_view(), name='profile-search'),
]