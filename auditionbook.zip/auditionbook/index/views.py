from django.shortcuts import render, redirect
from django.db.models import Q
from django.urls import reverse_lazy
from django.http import HttpResponseRedirect
from django.contrib.auth.mixins import UserPassesTestMixin, LoginRequiredMixin
from django.http import HttpResponse
from django.contrib.auth.models import User, auth
from datetime import datetime, timedelta
from django.views import View
from django.views.generic.edit import UpdateView, DeleteView

# importing models from models
from .models import Feed
from .models import Post
from .models import CommentOnFeed
from .models import CommentOnPost
from .models import CommentOnVideo
from .models import Video

# Importing forms for views
from .forms import FeedForm 
from .forms import PostForm
from .forms import FeedCommentForm
from .forms import PostCommentForm
from .forms import VideoCommentForm
from .forms import VideoForm

# user profile model
from .models import UserProfile

def index(request):
    return render(request, 'index.html')

# Views for  payment handler
def success(request):
    return render(request, 'payment/success.html')

def cancel(request):
    return render(request, 'payment/cancel.html')

def failure(request):
    return render(request, 'payment/failure.html')

class FeedView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        feeds = Feed.objects.all().order_by('-created_on')
        form = FeedForm()
        context = {
            'feeds': feeds,
            'form': form,
        }
        return render(request, 'feed/feed.html', context)
    def post(self, request, *args, **kwargs):
        feeds = Feed.objects.all().order_by('-created_on')
        form = FeedForm(data=request.POST, files=request.FILES)
        if form.is_valid(): 
            new_feed = form.save(commit=False)
            new_feed.author = request.user
            new_feed.save()
        context = {
            'feeds': feeds,
            'form': form,
            
        }
        return render(request, 'feed/feed.html', context)


# views for post field
class PostView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        posts = Post.objects.all().order_by('-created_on')

        form = PostForm()

        context = {
            'posts': posts,
            'form': form,
        }
        return render(request, 'post/post.html', context)
    def post(self, request, *args, **kwargs):
        posts = Post.objects.all().order_by('-created_on')
        form = PostForm(request.POST)

        if form.is_valid():
            new_post = form.save(commit=False)
            new_post.author = request.user
            new_post.save()
        context = {
            'posts': posts,
            'form': form,
        }
        return render(request, 'post/post.html', context)

class FeedDetailView(LoginRequiredMixin, View):
    def get(self, request, pk, *args, **kwargs):
        post = Feed.objects.get(pk=pk)
        form = FeedCommentForm()

        comments = CommentOnFeed.objects.filter(post=post).order_by('-created_on')
        context = {
            'post': post,
            'form': form,
            'comments': comments
        }
        return render(request, 'feed/feeddetails.html', context)
    def post(self, request, pk, *args, **kwargs):
        post = Feed.objects.get(pk=pk)
        form = FeedCommentForm(request.POST)
        if form.is_valid():
            new_comment = form.save(commit=False)
            new_comment.author = request.user
            new_comment.post = post
            new_comment.save()
        comments = CommentOnFeed.objects.filter(post=post).order_by('created_on')
        context = {
            'post': post,
            'form': form,
            'comments':comments
        }
        return render(request, 'feed/feeddetails.html', context)


class PostDetailView(LoginRequiredMixin, View):
    def get(self, request, pk, *args, **kwargs):
        post = Post.objects.get(pk=pk)
        form = PostCommentForm()
        comments = CommentOnPost.objects.filter(post=post).order_by('created_on')
        context = {
            'post': post,
            'form': form,
            'comments': comments
        }
        return render(request, 'post/postdetails.html', context)
    def post(self, request, pk, *args, **kwargs):
        post = Post.objects.get(pk=pk)
        form = PostCommentForm(request.POST)
        if form.is_valid():
            new_comment = form.save(commit=False)
            new_comment.author = request.user
            new_comment.post = post
            new_comment.save()
        comments = CommentOnPost.objects.filter(post=post).order_by('-created_on')
        context = {
            'post': post,
            'form': form,
            'comments': comments
        }
        return render(request, 'post/postdetails.html', context)


class VideoDetailView(LoginRequiredMixin, View):
    def get(self, request, pk, *args, **kwargs):
        post = Video.objects.get(pk=pk)
        form = VideoCommentForm()
        comments = CommentOnVideo.objects.filter(post=post).order_by('created_on')
        context = {
            'post': post,
            'form': form,
            'comments': comments
        }
        return render(request, 'video/videodetails.html', context)
    def post(self, request, pk, *args, **kwargs):
        post = Video.objects.get(pk=pk)
        form = VideoCommentForm(request.POST)
        if form.is_valid():
            new_comment = form.save(commit=False)
            new_comment.author = request.user
            new_comment.post = post
            new_comment.save()
        comments = CommentOnVideo.objects.filter(post=post).order_by('-created_on')
        context = {
            'post': post,
            'form': form,
            'comments': comments
        }
        return render(request, 'video/videodetails.html', context)



class FeedEditView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Feed
    fields = ['caption']
    template_name = 'feed/feededit.html'

    def get_success_url(self):
        pk = self.kwargs['pk']
        return reverse_lazy('feed_detail',kwargs={'pk':pk})

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author


class PostEditView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = Post
    fields = ['discription']
    template_name = 'post/postedit.html'

    def get_success_url(self):
        pk = self.kwargs['pk']
        return reverse_lazy('post_detail',kwargs={'pk':pk})

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author


class FeedDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Feed
    template_name = 'feed/feeddelete.html'
    success_url = reverse_lazy('feed')

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author

class PostDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Post
    template_name = 'post/postdelete.html'
    success_url = reverse_lazy('post')

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author

class VideoDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = Video
    template_name = 'video/videodelete.html'
    success_url = reverse_lazy('video')

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author

class FeedCommentDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = CommentOnFeed
    template_name = 'feed/feedcommentdelete.html'
    success_url = reverse_lazy('feed')
    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author

class PostCommentDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = CommentOnPost
    template_name = 'post/postcommentdelete.html'
    success_url = reverse_lazy('post')

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author


class VideoCommentDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = CommentOnVideo
    template_name = 'video/videocommentdelete.html'
    success_url = reverse_lazy('video')

    def test_func(self):
        post = self.get_object()
        return self.request.user == post.author


class ProfileView(View):
    def get(self, request, pk, *args, **kwargs):
        profile = UserProfile.objects.get(pk=pk)
        user = profile.user
        feeds = Feed.objects.filter(author=user).order_by('-created_on')
        posts = Post.objects.filter(author=user).order_by('-created_on')
        videos = Video.objects.filter(author=user).order_by('-created_on')
        
        followers = profile.followers.all()
        if len(followers) == 0:
            is_following = False
        for follower in followers:
            if follower== request.user:
                is_following = True
                break
            else:
                is_following = False
        number_of_followers = len(followers)

        context = {
            'user': user,
            'profile': profile,
            'posts': posts,
            'feeds': feeds,
            'videos': videos,
            'is_following':is_following,
            'number_of_followers':number_of_followers,
        }
        return render(request, 'account/profile.html', context)

class ProfileEditView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = UserProfile
    fields = ['name','age','height','languages', 'bio', 'birth_date', 'location','experience', 'profile_picture']
    template_name = 'account/profile_edit.html'

    def get_success_url(self):
        pk= self.kwargs['pk']
        return reverse_lazy('profile', kwargs={'pk':pk})

    def test_func(self):
        profile = self.get_object()
        return self.request.user == profile.user

class AddFollower(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        profile = UserProfile.objects.get(pk=pk)
        profile.followers.add(request.user)

        return redirect('profile', pk=profile.pk)

class RemoveFollower(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        profile = UserProfile.objects.get(pk=pk)
        profile.followers.remove(request.user)

        return redirect('profile', pk=profile.pk)

class FeedAddLike(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        post = Feed.objects.get(pk=pk)

        is_like = False

        for like in post.likes.all():
            if like == request.user:
                is_like = True
                break
        if not is_like:
            post.likes.add(request.user)

        if is_like:
            post.likes.remove(request.user)

        next = request.POST.get('next', '/')
        print(pk)
        return HttpResponseRedirect(next)


class PostAddLike(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        post = Post.objects.get(pk=pk)

        is_like = False

        for like in post.likes.all():
            if like == request.user:
                is_like = True
                break
        if not is_like:
            post.likes.add(request.user)

        if is_like:
            post.likes.remove(request.user)

        next = request.POST.get('next', '/')
        print(pk)
        return HttpResponseRedirect(next)


class VideoAddLike(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        post = Video.objects.get(pk=pk)

        is_like = False

        for like in post.likes.all():
            if like == request.user:
                is_like = True
                break
        if not is_like:
            post.likes.add(request.user)

        if is_like:
            post.likes.remove(request.user)

        next = request.POST.get('next', '/')
        print(pk)
        return HttpResponseRedirect(next)


class VideoView(LoginRequiredMixin, View):
    def get(self, request, *args, **kwargs):
        videos = Video.objects.all().order_by('-created_on')
        form = VideoForm()
        context = {
            'videos': videos,
            'form': form,
        }
        return render(request, 'video/video.html', context)
    def post(self, request, *args, **kwargs):
        videos = Video.objects.all().order_by('-created_on')
        form = VideoForm(data=request.POST, files=request.FILES)
        if form.is_valid(): 
            new_vid = form.save(commit=False)
            new_vid.author = request.user
            new_vid.save()
        context = {
            'videos': videos,
            'form': form,
            
        }
        return render(request, 'video/video.html', context)

class FeedCommentAddLike(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        comment = CommentOnFeed.objects.get(pk=pk)

        is_like = False

        for like in comment.like.all():
            if like == request.user:
                is_like = True
                break
        if not is_like:
            comment.like.add(request.user)

        if is_like:
            comment.like.remove(request.user)

        next = request.POST.get('next', '/')
        print(pk)
        return HttpResponseRedirect(next)

class PostCommentAddLike(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        comment = CommentOnPost.objects.get(pk=pk)

        is_like = False

        for like in comment.like.all():
            if like == request.user:
                is_like = True
                break
        if not is_like:
            comment.like.add(request.user)

        if is_like:
            comment.like.remove(request.user)

        next = request.POST.get('next', '/')
        print(pk)
        return HttpResponseRedirect(next)

class VideoCommentAddLike(LoginRequiredMixin, View):
    def post(self, request, pk, *args, **kwargs):
        comment = CommentOnVideo.objects.get(pk=pk)

        is_like = False

        for like in comment.like.all():
            if like == request.user:
                is_like = True
                break
        if not is_like:
            comment.like.add(request.user)

        if is_like:
            comment.like.remove(request.user)

        next = request.POST.get('next', '/')
        print(pk)
        return HttpResponseRedirect(next)


class UserSearch(View):
    def get(self, request, *args, **kwargs):
        query = self.request.GET.get('query')
        profile_list = UserProfile.objects.filter(
            Q(user__username__icontains=query)
        )

        context = {
            "profile_list": profile_list,
        }
        return render(request, 'account/search.html', context)